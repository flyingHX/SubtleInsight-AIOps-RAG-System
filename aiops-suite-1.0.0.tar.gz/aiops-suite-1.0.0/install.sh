#!/usr/bin/env bash
# =============================================================================
# AIOps 智能告警 RAG 知识库套件 — 一键安装脚本
# 版本：1.0.0（与 INSTALL.md 保持一致）
# 用法：
#   bash install.sh                  # 全量安装
#   bash install.sh --skip-frontend  # 跳过前端构建（使用预构建 dist）
#   bash install.sh --skip-rag --skip-backend --skip-frontend
# =============================================================================
set -euo pipefail

VERSION="1.0.0"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"

SKIP_RAG=0; SKIP_BACKEND=0; SKIP_FRONTEND=0
for arg in "$@"; do
  case "$arg" in
    --skip-rag) SKIP_RAG=1 ;;
    --skip-backend) SKIP_BACKEND=1 ;;
    --skip-frontend) SKIP_FRONTEND=1 ;;
    -h|--help) echo "用法: bash install.sh [--skip-rag] [--skip-backend] [--skip-frontend]"; exit 0 ;;
    *) echo "未知参数: $arg（支持 --skip-rag / --skip-backend / --skip-frontend）"; exit 1 ;;
  esac
done

log() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[提示]\033[0m %s\n' "$*"; }

echo "AIOps 套件安装程序 v$VERSION（根目录：$ROOT）"

# ---------- [1/4] 环境检查 ----------
log "[1/4] 环境检查"
command -v "$PYTHON_BIN" >/dev/null 2>&1 || { echo "错误：未找到 $PYTHON_BIN，请安装 Python 3.10+ 后重试"; exit 1; }
"$PYTHON_BIN" --version
NODE_TOOL=""
if command -v pnpm >/dev/null 2>&1; then NODE_TOOL="pnpm"; elif command -v npm >/dev/null 2>&1; then NODE_TOOL="npm"; fi
if [ -z "$NODE_TOOL" ]; then
  warn "未检测到 pnpm/npm：将跳过前端构建，直接使用预构建产物 app/frontend/dist"
else
  echo "前端构建工具：$NODE_TOOL"
fi

install_python_deps() {
  local dir="$1"
  (
    cd "$dir"
    if [ ! -x .venv/bin/python ]; then
      "$PYTHON_BIN" -m venv .venv || { echo "错误：创建 venv 失败（Debian/Ubuntu 请先安装 python3-venv）"; exit 1; }
    fi
    .venv/bin/python -m pip install --upgrade pip -q
    .venv/bin/python -m pip install -r requirements.txt -q
  )
  echo "✔ Python 依赖安装完成：$dir（.venv）"
}

# ---------- [2/4] RAG 流水线 ----------
if [ "$SKIP_RAG" -eq 0 ]; then
  log "[2/4] RAG 流水线依赖（aiops-rag-system）"
  install_python_deps "$ROOT/aiops-rag-system"
  if [ ! -f "$ROOT/aiops-rag-system/.env" ]; then
    cp "$ROOT/aiops-rag-system/.env.example" "$ROOT/aiops-rag-system/.env"
    warn "已由 .env.example 生成 aiops-rag-system/.env，请填写 LLM_API_KEY 等配置"
  fi
fi

# ---------- [3/4] 控制台后端 ----------
if [ "$SKIP_BACKEND" -eq 0 ]; then
  log "[3/4] 控制台后端依赖（app/backend）"
  install_python_deps "$ROOT/app/backend"
fi

# ---------- [4/4] 控制台前端 ----------
if [ "$SKIP_FRONTEND" -eq 0 ]; then
  log "[4/4] 控制台前端（app/frontend）"
  if [ -f "$ROOT/app/frontend/dist/index.html" ]; then
    echo "✔ 检测到预构建产物 app/frontend/dist（可直接由 Nginx 托管）"
  else
    warn "未检测到 app/frontend/dist，需在目标机完成前端构建"
  fi
  if [ -n "$NODE_TOOL" ]; then
    BUILD_OK=0
    if ( cd "$ROOT/app/frontend" && "$NODE_TOOL" install ); then
      if [ "$NODE_TOOL" = "pnpm" ]; then
        ( cd "$ROOT/app/frontend" && "$NODE_TOOL" build ) && BUILD_OK=1
      else
        ( cd "$ROOT/app/frontend" && "$NODE_TOOL" run build ) && BUILD_OK=1
      fi
    fi
    if [ "$BUILD_OK" -eq 1 ]; then
      echo "✔ 前端生产构建完成"
    else
      warn "前端构建失败，预构建 dist 仍可使用"
    fi
  else
    warn "无 Node 环境，跳过前端构建，使用预构建 dist"
  fi
fi

log "安装完成，后续部署步骤"
cat <<'NEXT'
1) RAG 流水线：
   cd aiops-rag-system
   docker compose up -d                       # 拉起 etcd/MinIO/Milvus/Kafka/Redis/ES
   .venv/bin/python scripts/init_milvus.py    # 初始化集合/索引/分区（幂等）
   .venv/bin/python scripts/seed_cases.py     # 灌入种子案例
   .venv/bin/uvicorn src.main:app --host 0.0.0.0 --port 8001
   curl http://localhost:8001/healthz         # 存活探针
   curl http://localhost:8001/readyz          # 就绪探针（Kafka/Redis/Milvus）

2) 控制台后端（PostgreSQL 账号 / Alembic 迁移 / 演示种子 / 序列修复）：
   详见 docs/OPERATIONS_DEPLOYMENT_GUIDE.md §14~§16

3) 控制台前端：
   生产：Nginx 托管 app/frontend/dist
   开发：bash app/start_app_v2.sh

4) 完整部署（Compose/K8s/systemd/Nginx/备份恢复）：docs/OPERATIONS_DEPLOYMENT_GUIDE.md
   故障处置与灾备：docs/OPERATIONS_RUNBOOK.md
NEXT
