# AIOps 智能告警 RAG 知识库套件 — 安装指南

- 版本：1.0.0
- 构建日期：2026-09-12
- 安装包：`aiops-suite-1.0.0.tar.gz`

## 1. 套件组成

| 路径 | 说明 |
|------|------|
| `app/` | AIOps 控制台：React 前端 + FastAPI 后端（RBAC、审批流、知识库、Agent 工作台、审计与配置中心） |
| `app/frontend/dist/` | 前端生产构建产物（已预构建，可直接静态托管） |
| `aiops-rag-system/` | RAG 流水线：Webhook 接入 → Drain 标准化 → Kafka → Redis 去重 → Milvus 向量检索 → LLM 诊断 → 反馈闭环 |
| `docs/` | 控制台使用手册、FAQ、运维部署手册、运维 Runbook |
| `README.md` | 项目总览、目录关系与快速开始 |
| `.wiki.md` | 项目 Wiki 与对外 API 文档（RAG 7 个接口 + 控制台全部接口契约） |
| `install.sh` | 一键安装脚本：环境检查、Python 依赖安装、前端构建（可选） |

## 2. 环境要求

| 依赖 | 要求 | 用途 |
|------|------|------|
| Python | 3.10+ | RAG 流水线与控制台后端 |
| Node.js / pnpm | 18+ / 8+ | 仅前端重新构建需要；离线部署可直接使用预构建 `app/frontend/dist` |
| PostgreSQL | 12+ | 控制台业务库（Alembic 迁移，head：`b8f2c1d4e5a6`） |
| Redis / Kafka / Milvus(etcd+MinIO) / Elasticsearch | 见 docker-compose.yml | RAG 流水线中间件，`aiops-rag-system/docker-compose.yml` 一键拉起 |
| LLM_API_KEY | OpenAI 兼容接口密钥 | 诊断 / Agent / Embedding 调用，模板见 `aiops-rag-system/.env.example` |

## 3. 快速安装

```bash
tar -xzf aiops-suite-1.0.0.tar.gz
cd aiops-suite-1.0.0
bash install.sh                     # 全量安装
bash install.sh --skip-frontend     # 跳过前端构建，直接使用预构建 dist
```

`install.sh` 行为说明：

1. 检查 `python3` / `pnpm` / `npm` 环境；
2. 为 `aiops-rag-system` 与 `app/backend` 各创建独立 `.venv` 并安装 `requirements.txt`；
3. 首次运行自动由 `.env.example` 生成 `aiops-rag-system/.env`（需手工填写 `LLM_API_KEY`）；
4. 检测到 Node 环境时重新构建前端，构建失败或无 Node 环境时回退使用预构建 `app/frontend/dist`；
5. 完成后打印后续部署步骤。

## 4. 部署步骤概要

1. **RAG 流水线**

   ```bash
   cd aiops-rag-system
   docker compose up -d                     # 拉起 etcd/MinIO/Milvus/Kafka/Redis/ES
   .venv/bin/python scripts/init_milvus.py  # 初始化集合/索引/分区（幂等）
   .venv/bin/python scripts/seed_cases.py   # 灌入 10 条种子案例
   .venv/bin/uvicorn src.main:app --host 0.0.0.0 --port 8001
   curl http://localhost:8001/healthz       # 存活探针 -> {"status":"ok"}
   curl http://localhost:8001/readyz        # 就绪探针（Kafka/Redis/Milvus，fail-open）
   ```

2. **控制台后端**：PostgreSQL 账号、Alembic 迁移、演示种子与序列修复，见 `docs/OPERATIONS_DEPLOYMENT_GUIDE.md` §14~§16；
3. **控制台前端**：Nginx 托管 `app/frontend/dist`（含 `/blog` 静态页），或开发模式 `bash app/start_app_v2.sh`；
4. **进阶部署**：Compose / Kubernetes（含滚动升级与回滚）/ systemd / Nginx / 备份恢复矩阵，见 `docs/OPERATIONS_DEPLOYMENT_GUIDE.md`；
5. **故障处置**：日志定位、中间件故障矩阵、灾备演练与应急联系人，见 `docs/OPERATIONS_RUNBOOK.md`。

## 5. 完整性校验

```bash
sha256sum aiops-suite-1.0.0.tar.gz   # 与交付时提供的校验值比对
```
